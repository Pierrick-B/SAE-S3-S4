<template>
  <div id="footer">
    <h2>Footer</h2>
    <p>blablabla</p>
  </div>
</template>

<style scoped>
#footer{
  background: gray;
}
h2{
  padding: 0;
  margin: 0;
}
</style>