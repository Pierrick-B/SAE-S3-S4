import { defineStore } from 'pinia'
// Importez directement les traductions dans le store
import translations from '@/datasource/lang.json'

export const useLangStore = defineStore('lang', {
    state: () => ({
        language: 'fr',
    }),
    // Les getters nous permettent de créer des propriétés calculées à partir du state
    getters: {
        /**
         * Crée un objet plat contenant uniquement les traductions
         * pour la langue actuellement sélectionnée.
         */
        currentTranslations: (state) => {
            const result = {};
            // Parcourt chaque clé ("titreTest", "test", etc.)
            for (const key in translations) {
                // Assigne la bonne traduction à la clé correspondante
                // ex: result['titreTest'] = translations['titreTest']['fr']
                result[key] = translations[key][state.language];
            }
            return result;
        }
    },
    actions: {
        // L'action reste la même, elle change simplement la langue
        toggleLanguage() {
            this.language = this.language === 'fr' ? 'en' : 'fr';
        }
    }
})