let programmation = [
    {"nom":"Activite 1","prestataire":"prestataire 1","jour":"jeudi","heure_debut":"08h00","heure_fin":"10h00"},
    {"nom":"Activite 2","prestataire":"prestataire 2","jour":"jeudi","heure_debut":"10h00","heure_fin":"12h00"},
    {"nom":"Activite 3","prestataire":"prestataire 3","jour":"jeudi","heure_debut":"13h00","heure_fin":"15h00"},
    {"nom":"Activite 4","prestataire":"prestataire 4","jour":"jeudi","heure_debut":"15h00","heure_fin":"17h00"},
    
    {"nom":"Activite 5","prestataire":"prestataire 5","jour":"vendredi","heure_debut":"08h00","heure_fin":"10h00"},
    {"nom":"Activite 6","prestataire":"prestataire 6","jour":"vendredi","heure_debut":"10h00","heure_fin":"12h00"},
    {"nom":"Activite 7","prestataire":"prestataire 7","jour":"vendredi","heure_debut":"13h00","heure_fin":"15h00"},
    {"nom":"Activite 8","prestataire":"prestataire 8","jour":"vendredi","heure_debut":"15h00","heure_fin":"17h00"},

    {"nom":"Activite 9","prestataire":"prestataire 9","jour":"samedi","heure_debut":"08h00","heure_fin":"10h00"},
    {"nom":"Activite 10","prestataire":"prestataire 10","jour":"samedi","heure_debut":"10h00","heure_fin":"12h00"},
    {"nom":"Activite 11","prestataire":"prestataire 11","jour":"samedi","heure_debut":"13h00","heure_fin":"15h00"},
    {"nom":"Activite 12","prestataire":"prestataire 12","jour":"samedi","heure_debut":"15h00","heure_fin":"17h00"},

    {"nom":"Activite 13","prestataire":"prestataire 13","jour":"dimanche","heure_debut":"08h00","heure_fin":"10h00"},
    {"nom":"Activite 14","prestataire":"prestataire 14","jour":"dimanche","heure_debut":"10h00","heure_fin":"12h00"},
    {"nom":"Activite 15","prestataire":"prestataire 15","jour":"dimanche","heure_debut":"13h00","heure_fin":"15h00"},
    {"nom":"Activite 16","prestataire":"prestataire 16","jour":"dimanche","heure_debut":"15h00","heure_fin":"17h00"},
]

export{
    programmation
}