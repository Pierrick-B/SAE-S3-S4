<script setup>
import NavBar from '@/components/NavBar.vue';
import Footer from "@/components/Footer.vue";
import { useLangStore } from "@/stores/langStore.js";
import { storeToRefs } from "pinia";

const langStore = useLangStore();
// Récupérez les traductions réactives depuis le getter du store
const { currentTranslations } = storeToRefs(langStore);
</script>

<template>
  <NavBar title="lieu"></NavBar>
  <router-view></router-view>
  <h1>{{ currentTranslations.titreTest }}</h1>
  <Footer></Footer>
</template>

<style scoped>
</style>